<footer style="margin-top:80px; padding:40px 0; background:#fff; border-top:1px solid #eee;">
  <div class="container" style="text-align:center; color:#64748b;">
    © <?= date('Y') ?> StepUp Studio. All rights reserved.
  </div>
</footer>
