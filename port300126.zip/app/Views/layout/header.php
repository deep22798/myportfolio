<header class="site-header">
  <div class="container nav">
    <a href="/" class="logo">StepUp Studio</a>

    <nav>
      <a href="/">Home</a>
      <a href="/about">About</a>
      <a href="/projects">Projects</a>
      <a href="/contact">Contact</a>
    </nav>
  </div>
</header>
