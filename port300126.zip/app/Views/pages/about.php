<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>

<section>
  <div class="container" style="max-width:900px;">
    <h1>About Me</h1>
    <p>
      I’m a Flutter developer focused on clean, scalable apps.
    </p>
  </div>
</section>

<?= $this->endSection() ?>
