<?= $this->extend('admin/layout/main') ?>
<?= $this->section('content') ?>

<div class="admin-card">
  <h1>Projects</h1>

  <table class="admin-table">
    <tr>
      <th>Title</th>
      <th>Type</th>
    </tr>

    <?php foreach ($projects as $p): ?>
    <tr>
      <td><?= esc($p['title']) ?></td>
      <td><?= esc($p['type']) ?></td>
    </tr>
    <?php endforeach; ?>
  </table>
</div>

<?= $this->endSection() ?>
