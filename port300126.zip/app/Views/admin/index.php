<?= $this->extend('admin/layout/main') ?>
<?= $this->section('content') ?>

<h1>Dashboard</h1>

<div class="dashboard-grid">
  <div class="dashboard-card">
    <h3><?= $totalProjects ?></h3>
    <p>Projects</p>
  </div>

  <div class="dashboard-card">
    <h3><?= $totalSkills ?></h3>
    <p>Skills</p>
  </div>
</div>

<?= $this->endSection() ?>
