<header class="admin-header">
  <div>
    <strong>Welcome, <?= esc(session()->get('admin_name')) ?></strong>
  </div>
</header>
